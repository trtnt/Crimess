﻿using CrimeSpace.DAL;
using CrimeSpace.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CrimeSpace.DTO
{
    public class SpelerDTO
    {
      

        public int SpelerId { get; set; }
        [Required]
        public string SpelerNaam { get; set; }
        public string Wachtwoord { get; set; }

        public int Experience { get; set; }
        public string Rank { get; set; }
        public int Bescherming { get; set; }
        public int Geld { get; set; }
        public int Leven { get; set; }
        public List<SpelerModel> Spelers { get; set; }

  
        public SpelerDTO(SpelerModel v)
        {
            SpelerId = v.SpelerId;
            SpelerNaam = v.SpelerNaam;
            Experience = v.Experience;
            Rank = v.Rank;
            Bescherming = v.Bescherming;
            Geld = v.Geld;
            Leven = v.Leven;
        }

        public SpelerDTO()
        {

        }

        public SpelerDTO(List<SpelerModel> spelers)
        {
            this.Spelers = spelers;
        }
    }
}
