﻿using CrimeSpace.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CrimeSpace.DTO
{
    public class KlikmissieDTO
    {
        public int MissieId { get; set; }
        public int SpelerId { get; set; }
        public string Naam { get; set; }
        public List<BeloningModel> Beloningen { get; set; }
    }
}
