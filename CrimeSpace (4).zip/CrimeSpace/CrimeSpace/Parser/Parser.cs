﻿using CrimeSpace.DTO;
using CrimeSpace.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace CrimeSpace.Parser
{
    public class Parser
    {
        public static SpelerDTO DataSetToSpeler(DataSet set, int rowIndex)
        {
            return new SpelerDTO()
            {
                SpelerId = (int)set.Tables[0].Rows[rowIndex][0],
                SpelerNaam = (string)set.Tables[0].Rows[rowIndex][1],
                Experience = (int)set.Tables[0].Rows[rowIndex][2],
                Rank = (string)set.Tables[0].Rows[rowIndex][3],
                Leven = (int)set.Tables[0].Rows[rowIndex][4],
                Bescherming = (int)set.Tables[0].Rows[rowIndex][5],
                Geld = (int)set.Tables[0].Rows[rowIndex][6],
            };
        }

        public static SpelerDTO DataSetToSpelernaam(DataSet set, int rowIndex)
        {
            return new SpelerDTO()
            {
                SpelerNaam = (string)set.Tables[0].Rows[rowIndex][1],
            };
        }

        public static KlikmissieDTO DataSetToKlikmissie(DataSet set, int rowIndex)
        {
            return new KlikmissieDTO()
            {
                SpelerId = (int)set.Tables[0].Rows[rowIndex][0],
                Beloningen = (List<BeloningModel>)set.Tables[0].Rows[rowIndex][1],
                MissieId = (int)set.Tables[0].Rows[rowIndex][2],
                Naam = (string)set.Tables[0].Rows[rowIndex][3]
            };
        }

    }
}
