﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using CrimeSpace.Models;
using CrimeSpace.Interfaces;
using CrimeSpace.DTO;
using CrimeSpace.Containers;
using System.Data.SqlClient;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using CrimeSpace.DAL;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNet.Identity;

namespace CrimeSpace.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly SpelerContainer spelerContainer;

        public HomeController(SpelerContainer spelerContainer)
        {
            this.spelerContainer = spelerContainer;

        }


        public IActionResult Home()
        {
            List<SpelerModel> spelers = spelerContainer.GetAll();
            return View(spelers);
        }


        public IActionResult Login()
        { 
            return View();
        }


        [HttpPost]
        public async Task<ActionResult> Login(SpelerModel speler, string ReturnUrl)
        {
            try
            {
                string spelert = Convert.ToString(spelerContainer.GetByName(speler.SpelerNaam));
                if (CheckLogin(spelert))
                {
                    var claims = new List<Claim>
                {
                    new Claim(ClaimTypes.Name, speler.SpelerNaam)
                        
                };
                    var claimsIdentity = new ClaimsIdentity(claims, "Login");
                    await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(claimsIdentity));
                }
                return Redirect(ReturnUrl == null ? "/Home/BeginPagina" : ReturnUrl);
            }
            catch (Exception)
            {
               return View();
            }  
        }

        public ActionResult Registreren(SpelerModel speler)
        {
            spelerContainer.InsertPlayer(speler);
            
            return RedirectToAction("BeginPagina", "Home");
        }

        [HttpGet]
        public IActionResult MisdaadView()
        {
            SpelerModel speler = spelerContainer.GetByName(User.Identity.Name);
            return View("~/Views/InGame/MisdaadView.cshtml", speler);
        }
        [HttpGet]
        public IActionResult BeginPagina()
        {
            SpelerModel speler = spelerContainer.GetByName(User.Identity.Name);

            return View("~/Views/InGame/BeginPagina.cshtml", speler);
        }

        public PartialViewResult MisdaadLayout(SpelerModel speler)
        {
            speler = spelerContainer.GetByName(User.Identity.Name);
            ViewBag.spelerNaam = speler.SpelerNaam;
            ViewBag.experience = speler.Experience;
            ViewBag.rank = speler.Rank;
            ViewBag.leven = speler.Leven;
            ViewBag.geld = speler.Geld;

            return PartialView("~/Views/Shared/_MisdaadLayout.cshtml", speler);
        }

        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync();
            return View("Login");
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public bool CheckLogin(string spelernaam)
        {
            //Alle spelers checken die in DB staan
            List<SpelerModel> spelers = spelerContainer.GetAll();
            //Check of naam in DB staat, alle strings naar upper zodat er geen verschil is in hoofdletters of kleine letters.
            var spelernaam1 = (from u in spelers
                               where u.SpelerNaam.ToUpper() == spelernaam.ToUpper()
                               select new
                               { spelernaam }).FirstOrDefault();

            bool status;

            if (spelernaam1 != null)
            {
                status = false;
            }
            else
            {
                status = true;
            }
            return status;

        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
