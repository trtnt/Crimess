﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CrimeSpace.Containers;
using CrimeSpace.Models;
using Microsoft.AspNetCore.Mvc;

namespace CrimeSpace.Controllers
{
    public class KlikmissieController : Controller
    {
        private readonly SpelerContainer spelerContainer;

        public KlikmissieController(SpelerContainer spelerContainer)
        {
            this.spelerContainer = spelerContainer;

        }
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Beginpagina()
        {
            SpelerModel speler = spelerContainer.GetByName(User.Identity.Name);
        
            return View("~/Views/InGame/Beginpagina.cshtml", speler);
        }

        public void Misdaadplegen()
        {
            
        }
        public IActionResult MisdaadView()
        {
            return View("~/Views/InGame/MisdaadView.cshtml");
        }
    }
}
