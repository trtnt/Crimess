﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CrimeSpace.Models;
using Microsoft.AspNetCore.Mvc;

namespace CrimeSpace.Controllers
{
    public class SpelerController : Controller
    {

        public IActionResult Index()
        {
            return View();
        }
    }
}
