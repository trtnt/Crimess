﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CrimeSpace.Models
{
    public class StatistiekenModel
    {
        public int Geld { get; set; }
        public int Experience { get; set; }
        public string Rank { get; set; }
        public int Leven { get; set; }
        public int Bescherming { get; set; }
    }
}
