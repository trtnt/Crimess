﻿using CrimeSpace.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CrimeSpace.Models
{
    public class KlikmissieModel
    {
        public int MissieId { get; set; }
        public int SpelerId { get; set; }
        public string Naam { get; set; }
        public List<BeloningModel> Beloningen { get; set; }

        public KlikmissieModel(KlikmissieDTO klikmissieDTO)
        {
            MissieId = klikmissieDTO.MissieId;
            SpelerId = klikmissieDTO.SpelerId;
            Naam = klikmissieDTO.Naam;
            Beloningen = klikmissieDTO.Beloningen;
        }
    }

    
}
