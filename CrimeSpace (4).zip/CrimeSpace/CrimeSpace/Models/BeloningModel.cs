﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CrimeSpace.Models
{
    public class BeloningModel
    {
        public int BeloningId { get; set; }
        public int MissieId { get; set; }
        public int SpelerId { get; set; }
        public string BeloningNaam { get; set; }
        public int BeloningExperience { get; set; }
        public float BeloningGeld { get; set; }

    }
}
