﻿using CrimeSpace.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CrimeSpace.Models
{
    public class SpelerModel : StatistiekenModel
    {

        public int SpelerId { get; set; }
        [Required]
        public string SpelerNaam { get; set; }
        public string Wachtwoord { get; set; }
        public List<SpelerDTO> Spelers { get; set; }


        public SpelerModel(SpelerDTO v)
        {
            SpelerId = v.SpelerId;
            SpelerNaam = v.SpelerNaam;
            Experience = v.Experience;
            Rank = v.Rank;
            Bescherming = v.Bescherming;
            Geld = v.Geld;
            Leven = v.Leven;
        }

        public SpelerModel( int spelerId, string spelerNaam, int experience, string rank, int bescherming, int geld)
        {
            SpelerId = spelerId;
            SpelerNaam = spelerNaam;
            Experience = experience;
            Rank = rank;
            Bescherming = bescherming;
            Geld = geld;
        }

        public SpelerModel()
        {
            
        }
    }
}
