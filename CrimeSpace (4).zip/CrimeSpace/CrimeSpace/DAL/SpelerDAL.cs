﻿using CrimeSpace.DAL.Interfaces;
using CrimeSpace.DTO;
using CrimeSpace.Interfaces;
using CrimeSpace.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace CrimeSpace.DAL
{
    //Inherit functies voor DAL queries uit SQLbase
    //Interface voor SpelerDAL
    //Interface voor de Container
    public class SpelerDAL : SQLBase, ISpelerDAL, ISpelerContainerDAL
    {
        private readonly string _connectionString = "Data Source=DESKTOP-JA9OFG0\\SQLEXPRESS;Initial Catalog=nosleepdb;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False;";

        public SpelerDAL()
        {
            //Connection string oproepen vanuit SQLBase
        }

        //DTO speler toevoegen in DB 
        public void InsertPlayer(SpelerModel t)
        {
            using SqlConnection connection = new SqlConnection(_connectionString);
            string query = "INSERT INTO dbo.Speler (spelerNaam,Experience,Rank,Leven,Bescherming,Geld) VALUES (@spelernaam,@experience,@rank,@leven,@bescherming,@geld)";

            using SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@spelernaam", t.SpelerNaam);
            command.Parameters.AddWithValue("@experience", t.Experience);
            command.Parameters.AddWithValue("@rank", t.Rank).Value = "Blue";
            command.Parameters.AddWithValue("@leven", t.Leven);
            command.Parameters.AddWithValue("@bescherming", t.Bescherming);
            command.Parameters.AddWithValue("@geld", t.Geld);

            connection.Open();

            int result = command.ExecuteNonQuery();

            if (result < 0)
                Console.WriteLine("Error inserting data into Database!");
            connection.Close();
        }

        //DTO update player 
        public void UpdatePlayer(SpelerDTO Speler)
        {
            using SqlConnection connection = new SqlConnection(_connectionString);
            string query = "UPDATE Speler (Experience, Geld, Leven, Rank) VALUES(@exp, @geld, @leven, @rank) " +
                "WHERE Experience = '" + Speler.Experience + "' AND Geld = '" + Speler.Geld + "' " +
                "AND Rank '" + Speler.Rank + "' AND Rank '" + Speler.Leven + "'";

            using SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@spelernaam", Speler.SpelerNaam);
            command.Parameters.AddWithValue("@geld", Speler.Geld);
            command.Parameters.AddWithValue("@exp", Speler.Experience);
            command.Parameters.AddWithValue("@rank", Speler.Rank);
            command.Parameters.AddWithValue("@leven", Speler.Leven);

            connection.Open();

            command.ExecuteNonQuery();

            connection.Close();
        }

        public List<SpelerDTO> GetAll()
        {
            List<SpelerDTO> Spelerlist = new List<SpelerDTO>();
            try
            {
                string sql = "SELECT * FROM Speler";

                DataSet results = ExecuteSql(sql, new List<KeyValuePair<string, string>>());

                for (int x = 0; x < results.Tables[0].Rows.Count; x++)
                {
                    SpelerDTO c = Parser.Parser.DataSetToSpeler(results, x);
                    Spelerlist.Add(c);
                }
                return Spelerlist;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public SpelerDTO GetByID(long id)
        {
            try
            {
                string sql = "SELECT * FROM Speler WHERE SpelerId = @SpelerId";
                List<KeyValuePair<string, string>> parameters = new List<KeyValuePair<string, string>>()
                {
                    new KeyValuePair<string,string>("@SpelerId", id.ToString())
                };

                DataSet results = ExecuteSql(sql, parameters);
                SpelerDTO c = Parser.Parser.DataSetToSpeler(results, 0);
                return c;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public SpelerDTO GetByName(string spelernaam)
        {
            try
            {
                string sql = "SELECT * FROM Speler WHERE spelerNaam = @spelernaam";
                List<KeyValuePair<string, string>> parameters = new List<KeyValuePair<string, string>>()
                {
                   new KeyValuePair<string,string>("@spelernaam", spelernaam)
                };

                DataSet results = ExecuteSql(sql, parameters);
                SpelerDTO c = Parser.Parser.DataSetToSpeler(results, 0);
                return c;
            }
            catch (Exception e)
            {
                throw e;
            }
        }


        public void Insert(SpelerDTO t)
        {
            try
            {
                string sql = "INSERT INTO Speler(SpelerId, SpelerNaam, Experience, Geld, Bescherming, Rank, Geld, Leven) VALUES (@spelerId, @spelerNaam, @experience, @geld, @bescherming, @rank, @geld, @leven)";
                List<KeyValuePair<string, string>> parameters = new List<KeyValuePair<string, string>>()
                {
                    new KeyValuePair<string, string>("@spelerId", t.SpelerId.ToString()),
                    new KeyValuePair<string, string>("@spelerNaam", t.SpelerNaam.ToString()),
                    new KeyValuePair<string, string>("@experience", t.Experience.ToString()),
                    new KeyValuePair<string, string>("@geld", t.Geld.ToString()),
                    new KeyValuePair<string, string>("@bescherming", t.Bescherming.ToString()),
                    new KeyValuePair<string, string>("@leven", t.Leven.ToString()),
                    new KeyValuePair<string, string>("@rank", t.Rank.ToString())
                };
               ExecuteInsert(sql, parameters);  
            }
            catch
            {
                throw;
            }
        }

        public void Update(SpelerDTO obj)
        {
            throw new NotImplementedException();
        }


    }
}
