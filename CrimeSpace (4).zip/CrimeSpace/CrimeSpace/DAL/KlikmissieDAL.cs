﻿using CrimeSpace.Containers.Interfaces;
using CrimeSpace.DAL.Interfaces;
using CrimeSpace.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace CrimeSpace.DAL
{
    public class KlikmissieDAL : SQLBase, IKlikmissieDAL, IKlikmissieContainerDAL
    {
        public List<KlikmissieDTO> GetAll()
        {
            List<KlikmissieDTO> KlikmissieList = new List<KlikmissieDTO>();
            try
            {
                string sql = "SELECT * FROM Misdaad";

                DataSet results = ExecuteSql(sql, new List<KeyValuePair<string, string>>());

                for (int x = 0; x < results.Tables[0].Rows.Count; x++)
                {
                    KlikmissieDTO c = Parser.Parser.DataSetToKlikmissie(results, x);
                    KlikmissieList.Add(c);
                }
                return KlikmissieList;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public KlikmissieDTO GetByID(long id)
        {
            try
            {
                string sql = "SELECT * FROM Speler WHERE MissieId = @MissieId";
                List<KeyValuePair<string, string>> parameters = new List<KeyValuePair<string, string>>()
                {
                    new KeyValuePair<string,string>("@MissieId", id.ToString())
                };

                DataSet results = ExecuteSql(sql, parameters);
                KlikmissieDTO c = Parser.Parser.DataSetToKlikmissie(results, 0);
                return c;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public void Insert(KlikmissieDTO obj)
        {
            throw new NotImplementedException();
        }


        public void Update(KlikmissieDTO obj)
        {
            throw new NotImplementedException();
        }

    }
}
