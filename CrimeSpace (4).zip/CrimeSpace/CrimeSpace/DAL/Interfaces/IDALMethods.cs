﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CrimeSpace.DAL.Interfaces
{
    public interface IDALMethods<T>
    {
        void Insert(T obj);
        void Update(T obj);
    }
}
