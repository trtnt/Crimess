﻿using CrimeSpace.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CrimeSpace.DAL.Interfaces
{
    interface IKlikmissieDAL : IDALMethods<KlikmissieDTO>
    {
    }
}
