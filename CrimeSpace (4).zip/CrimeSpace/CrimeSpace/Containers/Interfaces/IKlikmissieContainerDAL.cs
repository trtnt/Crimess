﻿using CrimeSpace.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CrimeSpace.Containers.Interfaces
{
    public interface IKlikmissieContainerDAL : IContainerDALMethods<KlikmissieDTO>
    {
        public List<KlikmissieDTO> GetAll()
        {
            throw new NotImplementedException();
        }

        public KlikmissieDTO GetByID(long id)
        {
            throw new NotImplementedException();
        }
    }
}
