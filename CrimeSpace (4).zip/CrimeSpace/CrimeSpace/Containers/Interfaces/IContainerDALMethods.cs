﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CrimeSpace.Containers.Interfaces
{
    public interface IContainerDALMethods<T>
    {
        T GetByID(long id);
        List<T> GetAll();
       
    }
}
