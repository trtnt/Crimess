﻿
using CrimeSpace.Containers.Interfaces;
using CrimeSpace.DTO;
using CrimeSpace.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CrimeSpace.Interfaces
{
    public interface ISpelerContainerDAL : IContainerDALMethods<SpelerDTO>
    {
        List<SpelerDTO> GetAll();
        SpelerDTO GetByID(long id);
        SpelerDTO GetByName(string spelernaam);
        void InsertPlayer(SpelerModel speler);
    }
}
