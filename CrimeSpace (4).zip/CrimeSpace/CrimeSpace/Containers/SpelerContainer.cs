﻿using CrimeSpace.DAL;
using CrimeSpace.DTO;
using CrimeSpace.Interfaces;
using CrimeSpace.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CrimeSpace.Containers
{
    public class SpelerContainer
    {
        protected readonly ISpelerContainerDAL _context;
        public SpelerContainer(ISpelerContainerDAL context)
        {
            _context = context;
        }
        
        //Lijst vanuit DTO naar een SpelerModel Lijst
        public List<SpelerModel> GetAll()
        {
            List<SpelerModel> spelers = new List<SpelerModel>();

            foreach (SpelerDTO dto in _context.GetAll())
            {
                SpelerModel speler = new SpelerModel(dto);
                spelers.Add(speler);
            }

            return spelers;
        }

  
        public void InsertPlayer(SpelerModel speler)
        { 
           _context.InsertPlayer(speler);
        }

        public SpelerModel GetByID(long id)
        {
            SpelerDTO spelerDTO = _context.GetByID(id);
            SpelerModel speler = new SpelerModel(spelerDTO);

            return speler;
        }

        public SpelerModel GetByName(string spelernaam)
        {
            SpelerDTO spelerDTO = _context.GetByName(spelernaam);
            SpelerModel speler = new SpelerModel(spelerDTO);

            return speler;
        }
    }
}
