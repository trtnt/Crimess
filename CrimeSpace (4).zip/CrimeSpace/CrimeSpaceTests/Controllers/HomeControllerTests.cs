﻿using Microsoft.VisualStudio.TestTools.UnitTesting;


namespace CrimeSpace.Controllers.Tests
{
    [TestClass()]
    public class HomeControllerTests
    {
        [TestMethod()]
        public void HomeTest()
        {
            Assert.Fail();
        }
    }
}