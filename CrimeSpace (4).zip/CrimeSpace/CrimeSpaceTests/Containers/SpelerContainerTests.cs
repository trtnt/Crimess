﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using CrimeSpace.Containers;
using System;
using System.Collections.Generic;
using System.Text;

namespace CrimeSpace.Containers.Tests
{
    [TestClass()]
    public class SpelerContainerTests
    {
        [TestMethod()]
        public void GetAllTest()
        {
            Assert.Fail();
        }
    }
}