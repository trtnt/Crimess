﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using CrimeSpace.DAL;
using System;
using System.Collections.Generic;
using System.Text;

namespace CrimeSpace.DAL.Tests
{
    [TestClass()]
    public class SpelerDALTests
    {
        [TestMethod()]
        public void insertPlayerTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void UpdatePlayerTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void GetAllTest()
        {
            Assert.Fail();
        }
    }
}